
The "signature" file provides the ".zip" file sign generated from the Hodgikin-Huxley NeuronBuilder.
This signature is unique and is generated using the ".zip" file read bitwise. 
If you want to upload a previously downloaded ".zip" file, you must provide the original "signature.txt" otherwise the file will be rejected.
