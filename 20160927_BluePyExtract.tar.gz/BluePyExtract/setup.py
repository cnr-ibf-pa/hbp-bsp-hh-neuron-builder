from distutils.core import setup

setup(
    name='BluePyExtract',
    version='0.1dev',
    packages=['bluepyextract',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
)
